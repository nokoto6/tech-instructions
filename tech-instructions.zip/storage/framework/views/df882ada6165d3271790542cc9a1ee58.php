<?php
    use App\Models\Instructions;
    
    $page = app('request')->input('page');
    $filter = app('request')->input('filter');

    if(!isset($categories)) { $categories = []; }
    if(!isset($page)) { $page = 1; }

?>



<?php $__env->startSection("admin-content"); ?>
    <h1 class="main-title">Категории</h1>

    <a class="cute-button-link" href="<?php echo e(route('category-form')); ?>">Создать категорию</a><br>

    <?php if(count($categories)): ?> 
        <ul class="cards-list">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="cute-border__template cards-item cards-item_admin">
                    <span class="admin-cards__text admin-cards__text_name">
                        #<?php echo e($item->id); ?> | <?php echo e($item->item_name); ?>

                    </span>
                    <span class="admin-cards__text admin-cards__text_symbol">
                        <span>
                            Google символы: <?php echo e($item->google_symbol_name); ?>

                        </span>
                        <span class="material-symbols-rounded category-item__symbol">
                            <?php echo e($item->google_symbol_name); ?>

                        </span>
                    </span>
                    <span class="admin-cards__text admin-cards__text_date">
                        Создано <?php echo e($item->created_at->format('d.m.Y')); ?>

                    </span>
                    <?php if(!Instructions::where(['category_id' => $item->id])->get()->first()): ?>
                        <form method="post" action="<?php echo e(route('category-delete', ['id' => $item->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <input 
                                class="cute-button-form cute-button-form_small cute-button-form_red" 
                                type="submit" 
                                name="submit" 
                                value="Удалить">
                        </form>
                    <?php else: ?>
                        <span class="admin-cards__text admin-cards__text_date">
                            Удаление невозможно, категория уже освоена
                        </span>
                    <?php endif; ?>
                    <a class="cute-button-link" href="<?php echo e(route('category-form', ['id' => $item->id])); ?>">Редактировать</a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <span>Список пуст</span>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("pages/admin-panel", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/admin/categories.blade.php ENDPATH**/ ?>