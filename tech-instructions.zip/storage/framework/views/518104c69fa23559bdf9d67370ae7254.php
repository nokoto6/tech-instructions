<?php
    use App\Models\Category;

    $page = app('request')->input('page');
    $filter = app('request')->input('filter');

    if(!isset($instructions)) { $instructions = []; }
    if(!isset($page)) { $page = 1; }
    if(!isset($filter)) { $filter = 'all'; }

    $filterNav = [
        'all' => 'Все',
        'accepted' => 'Одобренные',
        'notaccepted' => 'Неодобренные'
    ];

    if( $instructions ) {
        $pageCount = ceil($instructions->total() / $instructions->perPage());
        $pagination = getPagination($page, $pageCount);
        $onEachSide = count($pagination);
    }
?>



<?php $__env->startSection("admin-content"); ?>
    <?php if(isset($filterNav) && isset($filterNav[$filter]) ): ?> 
        <h1 class="main-title"><?php echo e($filterNav[$filter]); ?> инструкции</h1>
    <?php endif; ?>
    
    <a class="cute-button-link" href="<?php echo e(route('instruction-form')); ?>">Создать инструкцию</a>

    <?php if($instructions->total() > $instructions->perPage()): ?>
        <div class="paginate_container">
            <?php if( $pageCount > 5 && $page > 3 ): ?>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-instructions', ['filter' => $filter, 'page' => 1])); ?>">
                    <div class="cute-paginate-box__text">1</div>
                </a>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
            <?php endif; ?>
            
            <?php $__currentLoopData = $pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="cute-paginate-box <?php if($pageNum == $page): ?> cute-paginate-box_active <?php endif; ?>" href="<?php echo e(route('admin-instructions', ['filter' => $filter, 'page' => $pageNum])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageNum); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if( $pageCount > 5 && ($pageCount - $page) > 2  ): ?>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-instructions', ['filter' => $filter, 'page' => $pageCount])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageCount); ?></div>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <ul class="cards-list">
        <?php $__currentLoopData = $instructions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="cute-border__template cards-item">
                <div class="instruction-item__text-container">
                    <a href="/" class="instruction-item__text instruction-item__category">
                        <?php echo e(Category::whereKey($item->category_id)->get()->first()->item_name); ?>

                    </a>
                    <span class="instruction-item__text instruction-item__name">
                        #<?php echo e($item->id); ?> | <?php echo e($item->item_name); ?>

                    </span>
                    <span class="instruction-item__text instruction-item__description">
                        <?php echo e($item->description); ?>

                    </span>
                    <span class="instruction-item__text instruction-item__description">
                        Создано <?php echo e($item->created_at->format('d.m.Y')); ?>

                    </span>
                    <div class="instriction-item__admin-button-container">
                        <?php if(!$item->accepted): ?>
                            <form method="post" action="<?php echo e(route('instruction-accept', ['id' => $item->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <input 
                                    class="cute-button-form cute-button-form_small" 
                                    type="submit" 
                                    name="submit" 
                                    value="Одобрить">
                            </form>
                        <?php endif; ?>
                    </div>
                    <div class="instriction-item__admin-button-container">
                        <form method="post" action="<?php echo e(route('instruction-delete', ['id' => $item->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <input 
                                class="cute-button-form cute-button-form_small cute-button-form_red" 
                                type="submit" 
                                name="submit" 
                                value="Удалить">
                        </form>
                    </div>
                </div>
                <a href="<?php echo e(route('instruction-view', ['id'=>$item->id])); ?>" class="instruction-item__symbol-container">
                    <span class="material-symbols-rounded cute-border__symbol">
                        arrow_forward_ios
                    </span>
                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <?php if($instructions->total() > $instructions->perPage()): ?>
        <div class="paginate_container">
            <?php if( $pageCount > 5 && $page > 3 ): ?>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-instructions', ['filter' => $filter, 'page' => 1])); ?>">
                    <div class="cute-paginate-box__text">1</div>
                </a>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
            <?php endif; ?>
            
            <?php $__currentLoopData = $pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="cute-paginate-box <?php if($pageNum == $page): ?> cute-paginate-box_active <?php endif; ?>" href="<?php echo e(route('admin-instructions', ['filter' => $filter, 'page' => $pageNum])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageNum); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if( $pageCount > 5 && ($pageCount - $page) > 2  ): ?>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-instructions', ['filter' => $filter, 'page' => $pageCount])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageCount); ?></div>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("pages/admin-panel", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/admin/instructions.blade.php ENDPATH**/ ?>