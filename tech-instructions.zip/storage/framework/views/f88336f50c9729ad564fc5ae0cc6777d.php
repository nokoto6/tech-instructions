<?php
    use App\Models\Category;

    $search = app('request')->input('search'); 
    $category = app('request')->input('category'); 
    $page = app('request')->input('page');

    if(!isset($page)) { $page = 1; }

    if(!isset($instructions)) { $instructions = []; }

    if( $instructions ) {
        $pageCount = ceil($instructions->total() / $instructions->perPage());

        $pagination = getPagination($page, $pageCount);
        $onEachSide = count($pagination);
    }

    $categories = Category::get();
    if( !$categories ) { $categories = []; }
?>



<?php $__env->startSection('title', 'Поиск инструкций'); ?>

<?php $__env->startSection("content"); ?>
    <div class="main-container">
        <h1 class="main-title">Поиск инструкций для техники</h1>

        <form class="search-form">
            <div class="search-form-container">
                <input class="cute-border__template cute-border__input-search" type="text" id="search" name="search" placeholder="Поиск инструкций"
                value="<?php echo e($search); ?>"
                />
                <div class="search-categories-button__container">
                    <div class="search-categories-button material-symbols-rounded">
                        settings
                    </div>
                </div>
            </div>
            <div class="select-container">
                <span class="select-label">
                    Искать в категории:
                </span>
                <div class="custom-select">
                    <select class="hidden-select" name="category">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>">
                                <?php echo e($item->item_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </form>

        <?php if($search || $category): ?>
            <div class="clear-search-container">
                <a href="<?php echo e(route('results')); ?>" class="cute-button-link">Сбросить поиск</a>
            </div>
        <?php endif; ?>

        <?php if( $instructions && count($instructions) ): ?>
            <?php if($search): ?>
                <span class="instruction-list_count">По вашему запросу '<?php echo e($search); ?>' результатов: <?php echo e($instructions->total()); ?></span>
            <?php else: ?>
                <span class="instruction-list_count">Всего инструкций: <?php echo e($instructions->total()); ?></span>
            <?php endif; ?>

            <?php if($instructions->total() > $instructions->perPage()): ?>
                <div class="paginate_container">
                    <?php if( $pageCount > 5 && $page > 3 ): ?>
                        <a class="cute-paginate-box" href="<?php echo e(route('results', ['search' => $search, 'category' => $category, 'page' => 1])); ?>">
                            <div class="cute-paginate-box__text">1</div>
                        </a>
                        <div class="paginate-dots">
                            <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                        </div>
                    <?php endif; ?>
                    
                    <?php $__currentLoopData = $pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="cute-paginate-box <?php if($pageNum == $page): ?> cute-paginate-box_active <?php endif; ?>" href="<?php echo e(route('results', ['search' => $search, 'category' => $category, 'page' => $pageNum])); ?>">
                            <div class="cute-paginate-box__text"><?php echo e($pageNum); ?></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if( $pageCount > 5 && ($pageCount - $page) > 2  ): ?>
                        <div class="paginate-dots">
                            <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                        </div>
                        <a class="cute-paginate-box" href="<?php echo e(route('results', ['search' => $search, 'category' => $category, 'page' => $pageCount])); ?>">
                            <div class="cute-paginate-box__text"><?php echo e($pageCount); ?></div>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <ul class="cards-list">
                <?php $__currentLoopData = $instructions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="cute-border__template cards-item">
                        <div class="instruction-item__text-container">
                            <a href="<?php echo e(route('results', ['category' => $item->category_id])); ?>" class="instruction-item__text instruction-item__category">
                                <?php echo e(Category::whereKey($item->category_id)->get()->first()->item_name); ?>

                            </a>
                            <span class="instruction-item__text instruction-item__name">
                                <?php echo e($item->item_name); ?>

                            </span>
                            <span class="instruction-item__text instruction-item__description">
                                <?php echo e($item->description); ?>

                            </span>
                        </div>
                        <a href="<?php echo e(route('instruction-view', ['id'=>$item->id])); ?>" class="instruction-item__symbol-container">
                            <span class="material-symbols-rounded cute-border__symbol">
                                arrow_forward_ios
                            </span>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <div class="paginate_container">
                <?php if($instructions->total() > $instructions->perPage()): ?>
                        <?php if( $pageCount > 5 && $page > 3 ): ?>
                            <a class="cute-paginate-box" href="<?php echo e(route('results', ['search' => $search, 'category' => $category, 'page' => 1])); ?>">
                                <div class="cute-paginate-box__text">1</div>
                            </a>
                            <div class="paginate-dots">
                                <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                            </div>
                        <?php endif; ?>
                        
                        <?php $__currentLoopData = $pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="cute-paginate-box <?php if($pageNum == $page): ?> cute-paginate-box_active <?php endif; ?>" href="<?php echo e(route('results', ['search' => $search, 'category' => $category, 'page' => $pageNum])); ?>">
                                <div class="cute-paginate-box__text"><?php echo e($pageNum); ?></div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if( $pageCount > 5 && ($pageCount - $page) > 2  ): ?>
                            <div class="paginate-dots">
                                <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                            </div>
                            <a class="cute-paginate-box" href="<?php echo e(route('results', ['search' => $search, 'category' => $category, 'page' => $pageCount])); ?>">
                                <div class="cute-paginate-box__text"><?php echo e($pageCount); ?></div>
                            </a>
                        <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <span class="instruction-list_count">По вашему запросу ничего не найдено</span>
        <?php endif; ?>
    </div>

    <script src="/js/select.js"></script>
    <script src="/js/search.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("body", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/results.blade.php ENDPATH**/ ?>