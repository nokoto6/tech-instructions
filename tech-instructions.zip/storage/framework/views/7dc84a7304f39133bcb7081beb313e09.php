<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="icon" type="image/x-icon" href="/favicon.ico">
        <link rel="stylesheet" href="/css/template.css">
        <link rel="stylesheet" href="/css/newstyle.css">
        <link rel="stylesheet" href="/css/media.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
        <?php if (! empty(trim($__env->yieldContent('title')))): ?> <title><?php echo $__env->yieldContent('title'); ?></title> <?php else: ?> <title>Главная</title> <?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalee67427ddad28b1fa5b3a4baf17c1836 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee67427ddad28b1fa5b3a4baf17c1836 = $attributes; } ?>
<?php $component = Rahul900day\Captcha\Views\Components\Js::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('captcha-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Rahul900day\Captcha\Views\Components\Js::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee67427ddad28b1fa5b3a4baf17c1836)): ?>
<?php $attributes = $__attributesOriginalee67427ddad28b1fa5b3a4baf17c1836; ?>
<?php unset($__attributesOriginalee67427ddad28b1fa5b3a4baf17c1836); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee67427ddad28b1fa5b3a4baf17c1836)): ?>
<?php $component = $__componentOriginalee67427ddad28b1fa5b3a4baf17c1836; ?>
<?php unset($__componentOriginalee67427ddad28b1fa5b3a4baf17c1836); ?>
<?php endif; ?>
        <!-- Yandex.Metrika counter -->
        <script type="text/javascript" >
            (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
            m[i].l=1*new Date();
            for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
            k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
            (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
        
            ym(98678399, "init", {
                clickmap:true,
                trackLinks:true,
                accurateTrackBounce:true
            });
        </script>
        <noscript><div><img src="https://mc.yandex.ru/watch/98678399" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
        <!-- /Yandex.Metrika counter -->
    </head>
    <body>
        <style> body { display: none; } </style>
        
        <?php echo $__env->make("header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="body">
            <?php $__env->startSection("content"); ?>
            <?php if (! empty(trim($__env->yieldContent('')))): ?> <?php else: ?> <?php echo $__env->make("main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?>
            <?php echo $__env->yieldSection(); ?>
        </div>

        <script src="/js/header.js"></script>
        <style> body { display: block; } </style>
    </body>
</html><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/body.blade.php ENDPATH**/ ?>