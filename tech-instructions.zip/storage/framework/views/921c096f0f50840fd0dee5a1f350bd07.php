<?php
    use App\Models\Category;

    $id = app('request')->input('id');

    $name = '';
    $symbol = '';

    if(!isset($id)) { 
        $id = null; 
    } else {
        $item = Category::whereKey($id)->get()->first();
        $name = $item->item_name;
        $symbol = $item->google_symbol_name;
    }
?>



<?php if($id): ?> 
    <?php $__env->startSection('title', 'Редактирование категории'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создание категории'); ?>
<?php endif; ?>

<?php $__env->startSection("content"); ?>
    <?php if($id): ?> 
        <h1 class="main-title">Редактирование категории</h1>
    <?php else: ?>
        <h1 class="main-title">Создание категории</h1>
    <?php endif; ?>
    
    <a class="cute-button-link" href="<?php echo e(url()->previous("/foo")); ?>">Назад</a> <br/>

    <div class="auth-container">
        <form 
            class="auth-form" 
            method="POST" 
            action="<?php if($id): ?> <?php echo e(route('category-create',['id' => $id])); ?>

                    <?php else: ?> <?php echo e(route('category-create')); ?>

                    <?php endif; ?>">
            <?php echo csrf_field(); ?>
            <div class="cute-input-text__container">
                <label for="item_name" class="cute-input-text__label">
                    <span>Название</span>
                    <span class="required">*</span>
                </label>
                <input class="cute-input-text__input" maxlength="80" type="text" name="item_name" id="item_name" value="<?php echo e($name); ?>" required>
            </div>

            <div class="cute-input-text__container">
                <label for="google_symbol_name" class="cute-input-text__label">
                    <span>Google символ</span>
                    <span class="required">*</span>
                    <span id="repeater" class="material-symbols-rounded">kitchen</span>
                </label>
                <input class="cute-input-text__input" maxlength="40" type="text" name="google_symbol_name" id="google_symbol_name" value="<?php echo e($symbol); ?>" required>
            </div>

            <?php if($errors->any()): ?>
                <ul class="invalid-feedback">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="invalid-feedback">
                            <strong><?php echo e($error); ?></strong>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <button class="cute-button-form" type="submit">Сохранить</button>
        </form>
    </div>

    <script src="/js/inputs.js"></script>

    <script>
        const inputElement = document.getElementById('google_symbol_name');
        const spanElement = document.getElementById('repeater');

        function updateSpan() {
            spanElement.textContent = inputElement.value;
        }

        inputElement.addEventListener('input', updateSpan);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("body", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/category-form.blade.php ENDPATH**/ ?>