<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/template.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title>Главная</title>
    <?php if (isset($component)) { $__componentOriginalee67427ddad28b1fa5b3a4baf17c1836 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee67427ddad28b1fa5b3a4baf17c1836 = $attributes; } ?>
<?php $component = Rahul900day\Captcha\Views\Components\Js::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('captcha-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Rahul900day\Captcha\Views\Components\Js::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee67427ddad28b1fa5b3a4baf17c1836)): ?>
<?php $attributes = $__attributesOriginalee67427ddad28b1fa5b3a4baf17c1836; ?>
<?php unset($__attributesOriginalee67427ddad28b1fa5b3a4baf17c1836); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee67427ddad28b1fa5b3a4baf17c1836)): ?>
<?php $component = $__componentOriginalee67427ddad28b1fa5b3a4baf17c1836; ?>
<?php unset($__componentOriginalee67427ddad28b1fa5b3a4baf17c1836); ?>
<?php endif; ?>
</head>
<body>
    <?php echo $__env->make("header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="body">
        <?php $__env->startSection("content"); ?>
        <?php if (! empty(trim($__env->yieldContent('')))): ?> <?php else: ?> <?php echo $__env->make("main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php endif; ?>
        <?php echo $__env->yieldSection(); ?>
    </div>
</body>
</html><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views//body.blade.php ENDPATH**/ ?>