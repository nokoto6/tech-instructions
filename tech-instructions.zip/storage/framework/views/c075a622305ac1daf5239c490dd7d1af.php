<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title>Главная</title>
</head>
<body>
    <h1>Главная страница</h1>

    <?php if(auth()->guard()->check()): ?>
        <p>Привет <?php echo e(Auth::user()->name); ?></p>
        <a href="<?php echo e(route('logout')); ?>">Выйти</a>
    <?php else: ?>
        <a href="<?php echo e(route('login')); ?>">Войти</a>
        <a href="<?php echo e(route('register')); ?>">Регистрация</a>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/home.blade.php ENDPATH**/ ?>