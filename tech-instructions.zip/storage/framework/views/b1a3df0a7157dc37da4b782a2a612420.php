<form method="POST" action="<?php echo e(route('registerCreate')); ?>">
    <?php echo csrf_field(); ?>
    <h1>Регистрация</h1>
    <label>Имя</label>
    <input type="text" name="name" value="">
    <label>E-Mail</label>
    <input type="email" name="email" value="">
    <label>Пароль</label>
    <input type="password" name="password" value="">
    <button type="submit">Зарегистрировать</button>
</form><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/register.blade.php ENDPATH**/ ?>