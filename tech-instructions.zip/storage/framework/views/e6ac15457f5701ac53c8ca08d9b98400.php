    <link rel="preconnect" href="https://www.google.com">
    <link rel="preconnect" href="https://www.gstatic.com" crossorigin>
    <script src="https://www.google.com/recaptcha/api.js?hl=en" async defer></script><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\storage\framework\views/4e3afe75a5f50e9486dee36fea27ce54.blade.php ENDPATH**/ ?>