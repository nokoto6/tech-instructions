<?php
    $page = app('request')->input('page');
    $filter = app('request')->input('filter');

    if(!isset($page)) { $page = 1; }

    if(!isset($filter)) { $filter = 'active'; }

    $filterNav = [
        'active' => 'Активные',
        'blocked' => 'Заблокированные'
    ];

    if( $users ) {
        $pageCount = ceil($users->total() / $users->perPage());
        $pagination = getPagination($page, $pageCount);
        $onEachSide = count($pagination);
    }
?>



<?php $__env->startSection("admin-content"); ?>
    <?php if(isset($filterNav) && isset($filterNav[$filter]) ): ?> 
        <h1 class="main-title"><?php echo e($filterNav[$filter]); ?> пользователи</h1>
    <?php endif; ?>

    <?php if($users->total() > $users->perPage()): ?>
        <div class="paginate_container">
            <?php if( $pageCount > 5 && $page > 3 ): ?>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-users', ['filter' => $filter, 'page' => 1])); ?>">
                    <div class="cute-paginate-box__text">1</div>
                </a>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
            <?php endif; ?>
            
            <?php $__currentLoopData = $pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="cute-paginate-box <?php if($pageNum == $page): ?> cute-paginate-box_active <?php endif; ?>" href="<?php echo e(route('admin-users', ['filter' => $filter, 'page' => $pageNum])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageNum); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if( $pageCount > 5 && ($pageCount - $page) > 2  ): ?>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-users', ['filter' => $filter, 'page' => $pageCount])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageCount); ?></div>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <ul class="cards-list">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="cute-border__template cards-item cards-item_admin">
                <div class="admin-cards__user-container">
                    <div>
                        <img class="user__logo" src="/images/avatar-placeholder.png"/>
                    </div>
                    <div class="cards-item_admin">
                        <span class="admin-cards__text admin-cards__text_name">
                            #<?php echo e($item->id); ?> | <?php echo e($item->name); ?>

                        </span>
                        <span class="admin-cards__text admin-cards__text_email">
                            E-Mail: <?php echo e($item->email); ?>

                        </span>
                        <span class="admin-cards__text admin-cards__text_date">
                            Создан <?php echo e($item->created_at->format('d.m.Y')); ?>

                        </span>
                    </div>
                </div>
                <?php if(!$item->is_admin): ?>
                    <form method="post" action="<?php echo e(route('user-block', ['id' => $item->id, 'block' => !$item->blocked])); ?>">
                        <?php echo csrf_field(); ?>
                        <input 
                            class="cute-button-form cute-button-form_small" 
                            type="submit" 
                            name="submit" 
                            value="<?php if($item->blocked): ?> Разблокировать <?php else: ?> Заблокировать <?php endif; ?>">
                    </form>
                    <form method="post" action="<?php echo e(route('user-delete', ['id' => $item->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <input 
                            class="cute-button-form cute-button-form_small cute-button-form_red" 
                            type="submit" 
                            name="submit" 
                            value="Удалить">
                    </form>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <?php if($users->total() > $users->perPage()): ?>
        <div class="paginate_container">
            <?php if( $pageCount > 5 && $page > 3 ): ?>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-users', ['filter' => $filter, 'page' => 1])); ?>">
                    <div class="cute-paginate-box__text">1</div>
                </a>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
            <?php endif; ?>
            
            <?php $__currentLoopData = $pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="cute-paginate-box <?php if($pageNum == $page): ?> cute-paginate-box_active <?php endif; ?>" href="<?php echo e(route('admin-users', ['filter' => $filter, 'page' => $pageNum])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageNum); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if( $pageCount > 5 && ($pageCount - $page) > 2  ): ?>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-users', ['filter' => $filter, 'page' => $pageCount])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageCount); ?></div>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("pages/admin-panel", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/admin/users.blade.php ENDPATH**/ ?>