<div <?php echo e($attributes->merge([
    'class' => $containerClass,
    'data-theme' => $theme,
    'data-size' => $size,
    'data-sitekey' => $site_key,
])); ?>></div>
<?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\vendor\rahul900day\laravel-captcha\src/../resources/views/components/container.blade.php ENDPATH**/ ?>