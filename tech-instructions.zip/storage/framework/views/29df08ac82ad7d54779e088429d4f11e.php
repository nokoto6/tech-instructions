<?php
    $page = app('request')->input('page');
    $filter = app('request')->input('filter');

    if(!isset($complaints)) { $complaints = []; }
    if(!isset($page)) { $page = 1; }

    if( $complaints ) {
        $pageCount = ceil($complaints->total() / $complaints->perPage());
        $pagination = getPagination($page, $pageCount);
        $onEachSide = count($pagination);
    }
?>



<?php $__env->startSection("admin-content"); ?>
    <h1 class="main-title">Жалобы на инструкции</h1>

    <?php if($complaints->total() > $complaints->perPage()): ?>
        <div class="paginate_container">
            <?php if( $pageCount > 5 && $page > 3 ): ?>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-complaints', ['page' => 1])); ?>">
                    <div class="cute-paginate-box__text">1</div>
                </a>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
            <?php endif; ?>
            
            <?php $__currentLoopData = $pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="cute-paginate-box <?php if($pageNum == $page): ?> cute-paginate-box_active <?php endif; ?>" href="<?php echo e(route('admin-complaints', ['page' => $pageNum])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageNum); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if( $pageCount > 5 && ($pageCount - $page) > 2  ): ?>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-complaints', ['page' => $pageCount])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageCount); ?></div>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if(count($complaints)): ?> 
        <ul class="cards-list">
            <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="cute-border__template cards-item cards-item_admin">
                    <span class="admin-cards__text admin-cards__text_name">
                        ID жалобы: <?php echo e($item->id); ?>

                    </span>
                    <span class="admin-cards__text admin-cards__text_email">
                        Описание: <?php echo e($item->description); ?>

                    </span>
                    <span class="admin-cards__text admin-cards__text_date">
                        Жалоба создана <?php echo e($item->created_at->format('d.m.Y')); ?>

                    </span>
                    <span class="admin-cards__text admin-cards__text_date">
                        ID пожаловавшегося: <?php echo e($item->uploader_id); ?>

                    </span>
                    <span class="admin-cards__text admin-cards__text_date">
                        ID инструкции: <?php echo e($item->instruction_id); ?>

                    </span>
                    <a class="cute-button-link" href="<?php echo e(route('instruction-view', ['id'=>$item->instruction_id])); ?>">Перейти к инструкции</a>
                    <form method="post" action="<?php echo e(route('complaint-delete', ['id' => $item->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <input 
                            class="cute-button-form cute-button-form_small cute-button-form_red" 
                            type="submit" 
                            name="submit" 
                            value="Удалить">
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <span>Список пуст</span>
    <?php endif; ?>

    <?php if($complaints->total() > $complaints->perPage()): ?>
        <div class="paginate_container">
            <?php if( $pageCount > 5 && $page > 3 ): ?>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-complaints', ['page' => 1])); ?>">
                    <div class="cute-paginate-box__text">1</div>
                </a>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
            <?php endif; ?>
            
            <?php $__currentLoopData = $pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="cute-paginate-box <?php if($pageNum == $page): ?> cute-paginate-box_active <?php endif; ?>" href="<?php echo e(route('admin-complaints', ['page' => $pageNum])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageNum); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if( $pageCount > 5 && ($pageCount - $page) > 2  ): ?>
                <div class="paginate-dots">
                    <div class="cute-paginate-box__symbol material-symbols-rounded">more_horiz</div>
                </div>
                <a class="cute-paginate-box" href="<?php echo e(route('admin-complaints', ['page' => $pageCount])); ?>">
                    <div class="cute-paginate-box__text"><?php echo e($pageCount); ?></div>
                </a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("pages/admin-panel", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/admin/complaints.blade.php ENDPATH**/ ?>