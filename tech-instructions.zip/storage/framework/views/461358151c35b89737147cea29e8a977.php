<?php
    use App\Models\Category;

    $categories = Category::get();
    if( !$categories ) { $categories = []; }
?>



<?php $__env->startSection('title', 'Создание инструкции'); ?>

<?php $__env->startSection("content"); ?>
    <div class="auth-container">
        <h1 class="main-title">Создание инструкции</h1>
        <form 
            class="auth-form"  
            method="POST" 
            action="<?php echo e(route('instruction-create')); ?>"
            enctype="multipart/form-data"
            onsubmit="submit()"
        >
            <?php echo csrf_field(); ?>
            
            <div class="cute-input-text__container">
                <label for="item_name" class="cute-input-text__label">
                    <span>Название техники</span>
                    <span class="required">*</span>
                </label>
                <input class="cute-input-text__input" maxlength="40" type="text" name="item_name" id="item_name" value="" required>
            </div>

            <div class="cute-input-text__container">
                <label for="description" class="cute-input-text__textarea-label">
                    <span>Описание</span>
                </label>
                <textarea class="cute-input-text__textarea" maxlength="255" type="text" name="description" id="description" value=""></textarea>
            </div>

            <div class="cute-input-other__container">
                <label for="category_id" class="cute-input-category-label">
                    <span>Категория</span>
                    <span class="required required_always">*</span>
                </label>
                <div class="select-container select-container_form">
                    <div class="custom-select">
                        <select class="hidden-select" id="category_id" name="category_id">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>">
                                    <?php echo e($item->item_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="cute-input-other__container">
                <label for="file" class="cute-input-category-label">
                    <span>Файл с инструкцией .PDF, не более 40мб</span>
                    <span class="required required_always">*</span>
                </label>
                <input class="cute-input-file" accept=".pdf" type="file" name="file" id="file" required>
            </div>

            <?php if($errors->any()): ?>
                <ul class="invalid-feedback">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <strong><?php echo e($error); ?></strong>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <?php if(Auth::user()->is_admin): ?>
                <li class="invalid-feedback invalid-feedback_hint">Инструкции администратора будут автоматически одобрены</li>
            <?php else: ?>
                <li class="invalid-feedback invalid-feedback_hint">Инструкция появится в общем доступе после одобрения администрации</li>
            <?php endif; ?>
            <button class="cute-button-form" type="submit">Добавить</button>
        </form>
    </div>

    <div class="loading">
        <span>Ожидайте, идет загрузка файла...</span>

        <div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>

        <a class="cute-button-link" href="<?php echo e(route('instruction-form')); ?>">Отменить отправку</a> <br/>
    </div>

    <script src="/js/inputs.js"></script>
    <script src="/js/select.js"></script>

    <script>
        function submit() {
            document.querySelector('.loading').classList.add('loading_active');
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("body", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/instruction-form.blade.php ENDPATH**/ ?>