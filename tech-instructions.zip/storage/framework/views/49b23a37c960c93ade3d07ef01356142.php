

<?php $__env->startSection('title', 'Регистрация'); ?>

<?php $__env->startSection("content"); ?>
    <h1 class="main-title">Регистрация</h1>
    
    <div class="auth-container">
        <form class="auth-form" method="POST" action="<?php echo e(route('registerCreate')); ?>">
            <?php echo csrf_field(); ?>
            <div class="cute-input-text__container">
                <label for="name" class="cute-input-text__label">
                    <span>Имя</span>
                    <span class="required">*</span>
                </label>
                <input class="cute-input-text__input" maxlength="40" type="text" name="name" id="name" value="" required>
            </div>

            <div class="cute-input-text__container">
                <label for="email" class="cute-input-text__label">
                    <span>E-Mail</span>
                    <span class="required">*</span>
                </label>
                <input class="cute-input-text__input" maxlength="255" type="email" name="email" id="email" value="" required>
            </div>

            <div class="cute-input-text__container margin-bottom-20">
                <label for="password" class="cute-input-text__label">
                    <span>Пароль</span>
                    <span class="required">*</span>
                </label>
                <input class="cute-input-text__input" maxlength="255" type="password" name="password" id="password" value="" required>
            </div>
            <?php if (isset($component)) { $__componentOriginal4de986a50b9cc5934962cd037daefa64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4de986a50b9cc5934962cd037daefa64 = $attributes; } ?>
<?php $component = Rahul900day\Captcha\Views\Components\Container::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('captcha-container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Rahul900day\Captcha\Views\Components\Container::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4de986a50b9cc5934962cd037daefa64)): ?>
<?php $attributes = $__attributesOriginal4de986a50b9cc5934962cd037daefa64; ?>
<?php unset($__attributesOriginal4de986a50b9cc5934962cd037daefa64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4de986a50b9cc5934962cd037daefa64)): ?>
<?php $component = $__componentOriginal4de986a50b9cc5934962cd037daefa64; ?>
<?php unset($__componentOriginal4de986a50b9cc5934962cd037daefa64); ?>
<?php endif; ?>
            <?php if($errors->any()): ?>
                <ul class="invalid-feedback">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="invalid-feedback">
                            <strong><?php echo e($error); ?></strong>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <?php if(DB::table('users')->count() == 0): ?>
                <li class="invalid-feedback notification__green">Первому созданному пользователю будут выданы admin привелегии, либо воспользуйтесь 'php artisan db:seed'</li>
            <?php endif; ?>
            <button class="cute-button-form" type="submit">Зарегистрироваться</button>
            <a class="cute-link-text" href="<?php echo e(route('login')); ?>">Уже есть аккаунт?</a>
        </form>
    </div>

    <script src="/js/inputs.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("body", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/register.blade.php ENDPATH**/ ?>