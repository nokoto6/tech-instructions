

<?php $__env->startSection("content"); ?>
    <div class="auth-container">
        <form method="POST" action="<?php echo e(route('instructionAdd')); ?>">
            <?php echo csrf_field(); ?>
            <h1>Создание инструкции</h1>
            <input class="simple-input simple-input__fillable" type="text" name="name" value="" placeholder="Название техники" required>
            <textarea class="simple-input simple-input__fillable simple-input__area" name="description" placeholder="Описание" required></textarea>
            <input class="simple-input simple-input__link" type="file" name="file">
            <div class="auth-border"></div>
            <?php if($errors->has('message')): ?>
                <span class="invalid-feedback">
                    <strong><?php echo e($errors->first('message')); ?></strong>
                </span>
            <?php endif; ?>
            <button class="simple-input simple-input__button" type="submit">Добавить</button>
        </form>
    <div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("body", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/createInstruction.blade.php ENDPATH**/ ?>