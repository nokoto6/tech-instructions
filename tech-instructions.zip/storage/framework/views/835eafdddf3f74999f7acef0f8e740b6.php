<form method="POST" action="<?php echo e(route('authentication')); ?>">
    <?php echo csrf_field(); ?>
    <h1>Авторизация</h1>
    <label>E-Mail</label>
    <input type="email" name="email" value="">
    <label>Пароль</label>
    <input type="password" name="password" value="">
    <button type="submit">Войти</button>
</form><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/login.blade.php ENDPATH**/ ?>