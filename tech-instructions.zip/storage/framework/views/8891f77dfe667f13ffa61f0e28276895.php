

<?php $__env->startSection('title', 'Создать пользователя'); ?>

<?php $__env->startSection("content"); ?>
    <a class="simple-input simple-input__button simple-input__link" href="<?php echo e(url()->previous("/foo")); ?>">Назад</a>

    <div class="auth-container">
        <form method="POST" action="<?php echo e(route('registerCreate', ['noAuth' => true])); ?>">
            <?php echo csrf_field(); ?>
            <h1>Создать пользователя</h1>
            <input class="simple-input simple-input__fillable" maxlength="40" type="text" name="name" value="" placeholder="Имя" required>
            <input class="simple-input simple-input__fillable" maxlength="255" type="email" name="email" value="" placeholder="E-Mail" required>
            <input class="simple-input simple-input__fillable" maxlength="255" type="password" name="password" value="" placeholder="Пароль" required>
            <div class="simple-input simple-input__fillable">
                <br/>
                <label for="is_admin">Имеет права администратора?</label>
                <input type="checkbox" id="is_admin" name="is_admin" value="1">
            </div>
            <div class="auth-border"></div>
            <?php if($errors->any()): ?>
                <ul class="invalid-feedback">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="invalid-feedback">
                            <strong><?php echo e($error); ?></strong>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <button class="simple-input simple-input__button" type="submit">Создать</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("body", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/user-create.blade.php ENDPATH**/ ?>