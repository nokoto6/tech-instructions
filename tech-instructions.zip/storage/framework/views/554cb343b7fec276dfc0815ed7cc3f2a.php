<?php
    use App\Models\User;
    use App\Models\Category;

    $categories = Category::get();
    if( !$categories ) { $categories = []; }
?>



<?php $__env->startSection('title', 'Инструкция к ' . $item->item_name); ?>

<?php $__env->startSection("content"); ?>
    <a class="cute-button-link" href="<?php echo e(url()->previous("/foo")); ?>">Назад</a>

    <div class="view-container">
        <h1 class="main-title">Инструкция к <?php echo e($item->item_name); ?></h1>

        <div class="item-view__container">

            <div>
                <span class="cute-bold-text">Категория устройства: </span>
                <span>
                    <?php echo e(Category::whereKey($item->category_id)->get()->first()->item_name); ?>

                </span>
            </div>

            <?php if($item->description): ?>
                <div>
                    <span class="cute-bold-text">Описание: </span>
                    <div class="item__description"><?php echo e($item->description); ?></div>
                </div>
            <?php endif; ?>

            <div>
                <span class="cute-bold-text">Инструкцию выложил: </span>
                <span><?php echo e(User::where(['id' => $item->uploader_id])->first()->name); ?></span>
            </div>
            
            <iframe class="item_view-iframe" src="<?php echo e($item['file']); ?>" seamless></iframe>

            <a class="cute-button-link" href="<?php echo e($item['file']); ?>" target=”_blank” type="submit">Открыть файл в новой вкладке</a>
            <a class="cute-button-link" href="<?php echo e($item['file']); ?>" download type="submit">Скачать файл</a>
        </div>

        <div class="complaints__container">
            <div class="complaints-help__container">
                <h3 class="complaints-help__text">С инструкцией что-то не так? Отправьте жалобу, администрация рассмотрит Ваш вопрос в ближайшее время</h3>
            </div>

            <div class="complaints-content">
                <div class="complaints-header__container">
                    <span class="complaints-close">&times;</span>
                    <h2 class="complaints-title">Отправить жалобу</h2>
                </div>
                <form 
                    method="POST" 
                    action="<?php echo e(route('complaint-create', ['instruction_id'=>$item->id])); ?>"
                >
                    <?php echo csrf_field(); ?>
                    <textarea class="cute-input-text__textarea" maxlength="255" name="description" placeholder="Описание" required></textarea>
                    <button class="cute-button-form" type="submit">Отправить</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("body", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/instruction-view.blade.php ENDPATH**/ ?>