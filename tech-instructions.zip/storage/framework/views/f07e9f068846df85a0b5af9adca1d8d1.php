

<?php
    $currentUrl = explode("?",Request::url())[0];

    $adminPanelLinks = array(
        route('admin-instructions') => "Инструкции",
        route('admin-users') => "Пользователи",
        route('admin-complaints') => "Жалобы",
        route('admin-categories') => "Категории"
    );

    $filter = app('request')->input('filter');
?>

<?php $__env->startSection('title', 'Админ панель'); ?>

<?php $__env->startSection("content"); ?>
    <style>
        @media (max-width: 560px) {
            .body {
                padding: 0;
                padding-top: 50px;
            }
        }
    </style>
    
    <div class="admin-panel">
        <div class="admin-navigation">
            <ul class="admin-nav-list">
                <?php $__currentLoopData = $adminPanelLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="admin-nav-item">
                        <a 
                            class="admin-nav-link <?php if($currentUrl === $url): ?> admin-nav-link_active <?php endif; ?>" href="<?php echo e($url); ?>" >
                            <?php echo e($title); ?>

                        </a>
                        <?php if($currentUrl === $url & isset($filterNav)): ?> 
                            <ul class="filter-nav-list">
                                <?php $key = 0; ?>
                                <?php $__currentLoopData = $filterNav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filterUrl => $filterTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $key++; ?>
                                    <li class="admin-nav-item">
                                        <a 
                                            class="admin-nav-link <?php if($filter === $filterUrl || !$filter && $key == 1): ?> admin-nav-link_active <?php endif; ?>" href="<?php echo e(url()->query($currentUrl, ['filter' => $filterUrl])); ?>" >
                                            <?php echo e($filterTitle); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="admin-main">
            <?php echo $__env->yieldContent("admin-content"); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("body", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/admin-panel.blade.php ENDPATH**/ ?>