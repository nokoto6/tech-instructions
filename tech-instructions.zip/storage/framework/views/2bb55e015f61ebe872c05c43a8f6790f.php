

<?php $__env->startSection('title', 'Категории'); ?>

<?php $__env->startSection("content"); ?>
    <h1 class="main-title">Категории</h1>

    <?php if($categories): ?>
        <ul class="category-list">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="cute-border__template category-item">
                    <a href="<?php echo e(route('results', ['category' => $item->id])); ?>" class="category-item__link">
                        <div href="" class="category-item__symbol-container">
                            <span class="material-symbols-rounded category-item__symbol">
                                <?php echo e($item->google_symbol_name); ?>

                            </span>
                        </div>
                        <div class="category-item__text-container">
                            <span class="category-item__text">
                                <?php echo e($item->item_name); ?>

                            </span>
                        </div>
                        <span class="category-item__arrow-container">
                            <span class="material-symbols-rounded category-item__arrow cute-border__symbol">
                                arrow_forward_ios
                            </span>
                        </span>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("body", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Никита\Desktop\laravel-hw\tech-instructions\resources\views/pages/categories.blade.php ENDPATH**/ ?>